new WOW().init();
var mySwiper = new Swiper('.swiper-container', {
    pagination: {
        el: '.slider-pagination',
        bulletClass: 'slider-bullet',
        clickable: true
    }
});